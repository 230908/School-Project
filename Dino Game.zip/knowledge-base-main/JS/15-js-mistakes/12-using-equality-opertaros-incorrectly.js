// 12. Using Equality Operators Incorrectly

"❌ A bad way ❌";

false === 0; //false
false == 0; //true
10 === '10' //false
10 ==  "10" //true

null == undefined //true
null == NaN //false

"✅ A good way ✅";
