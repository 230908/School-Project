<form action="send.php" method="POST">
    <label for="subject">Subject: <br><input type="text" name="subject"></label><br>
    <label for="body">Body of the email: <br> <textarea name="body" cols="30" rows="10"></textarea></label> <br>
    <input type="submit" value="Send">
</form>