<h1>Please enter the email for which you want to unsubscribe:</h1>

<form action="unscubscribe.php" method="POST">
    <label for="email">Email: <input type="text" name="email"></label> <br>
    <input type="submit" value="Unsubscribe">
</form>