let a = 5;
let b = "Hello World";

console.log(a, b);

console.log("Value is: " + a + " and string is : " + b);
